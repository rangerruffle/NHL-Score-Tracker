var awayScore = "0";
var awayTeamIcon = "logos/nhl.png";
var awayTeamId = 0;
var awayTeamInitial = "";
var awayTeamName = "";
var awayTeamOffense = [];
var awayTeamOnIce = [];
var awayTeamDefense = [];
var currentGameId = false;
var firstOpen = true;
var firstStatsSet = true;
var gameStatus = "None";
var gameTimeDataRefreshTimer = false;
var homeScore = "0";
var homeTeamIcon = "logos/nhl.png";
var homeTeamId = 0;
var homeTeamInitial = "";
var homeTeamName = "";
var homeTeamOffense = [];
var homeTeamOnIce = [];
var homeTeamDefense = [];
var otherTeamName = "";
var teamData = null;
var teamIcon = "";
var teamId = "";
var teamAbbv = "";
var teamName = "";
var today = new Date();
var todayMonth = today.getMonth() + 1;
if (todayMonth < 10) {
	todayMonth = '0' + todayMonth;
}
var todayDay = today.getDate();
if (todayDay < 10) {
	todayDay = '0' + todayDay;
}
var todayYear = today.getFullYear();

// Tabs
var calendarTab;
var previewTab;
var liveTab;
var teamStatsTab;
var playerStatsTab;
var standingsTab;
var activeTab;

// Sections
var calendar;
var rink;
var teamStats;
var inGamePlayerStats;
var playerStats;
var noGamePlayerStats;
var standings;

let commonUtilities = CommonPopupUtilities.init();
chrome.storage.sync.get([ 'trackedTeamName','trackedTimeZone' ], function(result) {
	if (!commonUtilities.getTeamAbbv()) {
		commonUtilities = CommonPopupUtilities.init();
	}
	
	teamName = commonUtilities.getTeamName();
	teamAbbv = commonUtilities.getTeamAbbv();
	teamId = commonUtilities.getTeamId();
	teamIcon = "logos/" + teamName + ".png";
});

chrome.alarms.create(
	"NHLScoreTrackerPopup",
	{
		when: Date.now(),
		periodInMinutes: 60
	}
);

chrome.alarms.onAlarm.addListener(function(alarm) {
	if (alarm.name = "NHLScoreTrackerPopup") {
		if (!commonUtilities.getTeamAbbv()) {
			commonUtilities = CommonPopupUtilities.init();
		}
		
		commonUtilities.updateData();

		// const headingRoot = document.getElementById("headingRoot");
		// const tabsRoot = document.getElementById("tabsRoot");
		// const mainSection = document.getElementById("mainSection");
		// addClass(headingRoot, commonUtilities.getTeamColorClass());
		// addClass(tabsRoot, commonUtilities.getTeamColorClass());
		// addClass(mainSection, commonUtilities.getTeamColorClass());

		updateGameData();
	}
});

function updateGameData() {
	calendarTab = document.getElementById("calendarTab");
	previewTab = document.getElementById("previewTab");
	liveTab = document.getElementById("liveTab");
	teamStatsTab = document.getElementById("teamStatsTab");
	playerStatsTab = document.getElementById("playerStatsTab");
	standingsTab = document.getElementById("standingsTab");
	
	calendar = document.getElementById("calendar");
	rink = document.getElementById("rink");
	teamStats = document.getElementById("gameTeamStats");
	inGamePlayerStats = document.getElementById("inGamePlayerStats");
	playerStats = document.getElementById("playerStats");
	noGamePlayerStats = document.getElementById("noGamePlayerStats");
	standings = document.getElementById("standings");
	
	nhlLink = document.getElementById("nhlLink");
	
	setTabListeners();
	setCalendarButtonListeners();
	setCalendar();
	
	fetch("https://api-web.nhle.com/v1/club-schedule-season/" + commonUtilities.getTeamAbbv() + "/now")
		.catch(error => {
			setNoGame();
		})
		.then(response => response.json())
		.then(scheduleInfo => {
			setScheduleData(scheduleInfo);
		});
}

function setScheduleData(scheduleInfo) {
	const todayYear = commonUtilities.getTodayYear();
	const todayMonth = commonUtilities.getTodayMonth();
	const todayDay = commonUtilities.getTodayDay();
	const gameIndex = scheduleInfo.games.findIndex(game => game.gameDate === todayYear + '-' + todayMonth + '-' + todayDay);
	
	if (gameIndex && gameIndex >= 0) {
		const todayGame = scheduleInfo.games[gameIndex];
		
		currentGameId = todayGame.id;
		var dateTime = new Date(todayGame.gameDate);
		localGameTime = getTimeZoneAdjustedTime(dateTime);
		
		fetch("https://api-web.nhle.com/v1/gamecenter/" + currentGameId + "/boxscore")
			.catch(error => {
				setNoGame();
			})
			.then(response => response.json())
			.then(gameInfo => {
				setGameData(gameInfo);
			});
	} else {
		gameStatus = "None";
		currentGameId = false;
		setFooterLinkHref("none", "", "", "");
		setNoGame();
	}
}

function setGameData(gameData) {
	const teamIsHome = gameData.homeTeam.id === teamId;
	const gameToday = currentGameId != false;
	
	if (gameToday) {
		awayScore = gameData.awayTeam.score;
		homeScore = gameData.homeTeam.score;
		otherTeamName = teamIsHome ? gameData.awayTeam.name.default : gameData.homeTeam.name.default;
		const awayTeamInitial = gameData.awayTeam.abbrev.toLowerCase();
		const homeTeamInitial = gameData.homeTeam.abbrev.toLowerCase();
		
		if (teamIsHome) {
			awayTeamIcon = "logos/" + otherTeamName + ".png";
			homeTeamIcon = teamIcon;

			awayTeamId = commonUtilities.getTeamIdMapping()[otherTeamName];
			homeTeamId = teamId;

			awayTeamName = otherTeamName;
			homeTeamName = teamName;

			drawAwayLogo("logos/" + otherTeamName + ".png");
			drawHomeLogo(teamIcon);
		} else {
			awayTeamIcon = teamIcon;
			homeTeamIcon = "logos/" + otherTeamName + ".png";

			awayTeamId = teamId;
			homeTeamId = commonUtilities.getTeamIdMapping()[otherTeamName];

			awayTeamName = teamName;
			homeTeamName = otherTeamName;

			drawAwayLogo(teamIcon);
			drawHomeLogo("logos/" + otherTeamName + ".png");
		}
		
		if (gameData.gameState === "FUT" || gameData.gameState === "PRE") {
			gameStatus = "Preview";
			setFooterLinkHref("preview", currentGameId, awayTeamInitial, homeTeamInitial);
			setPreview(gameData);
			currentlyPreGame = true;
		} else if (gameData.gameState === "FINAL" || gameData.gameState === "OFF") {
			gameStatus = "Final";
			setFooterLinkHref("final", currentGameId, awayTeamInitial, homeTeamInitial);
			setFinal(gameData);
			currentlyPreGame = false;
		} else if (gameData.gameState === "LIVE") {
			gameStatus = "Live";
			setFooterLinkHref("live", currentGameId, awayTeamInitial, homeTeamInitial);
			setLive(gameData);
			currentlyPreGame = false;
		}
	}
}

function startInGameDataUpdateTimerIfNeeded() {
	if (gameTimeDataRefreshTimer == false) {
		gameTimeDataRefreshTimer = setInterval(updateData, 3000);
	}
}

function updateData() {
	if (!commonUtilities.getTeamAbbv()) {
		commonUtilities = CommonPopupUtilities.init();
	}
	
	commonUtilities.updateData();
	updateGameData(todayYear, todayMonth, todayDay);
}

function setTabListeners() {
	calendarTab.addEventListener('click', function () {hideShowElements(calendar);}, false);
	previewTab.addEventListener('click', function () {hideShowElements(playerStats);}, false);
	liveTab.addEventListener('click', function () {hideShowElements(rink);}, false);
	teamStatsTab.addEventListener('click', function () {hideShowElements(teamStats);}, false);
	playerStatsTab.addEventListener('click', function () {
		if (gameStatus === "Preview") {
			hideShowElements(playerStats);
		} else if (gameStatus === "Final") {
			hideShowElements(inGamePlayerStats);
		} else if (gameStatus == "Live") {
			hideShowElements(inGamePlayerStats);
		} else {
			hideShowElements(noGamePlayerStats);
		}
	}, false);
	standingsTab.addEventListener('click', function () {hideShowElements(standings);}, false);
}

function setCalendarButtonListeners() {
	const previousMonth = document.getElementById("previousMonth");
	const nextMonth = document.getElementById("nextMonth");

	previousMonth.addEventListener(
		'click',
		function() {
			commonUtilities.setPreviousCurrentCalendarMonth();
			setCalendar();
		},
		false
	);
	nextMonth.addEventListener(
		'click',
		function() {
			commonUtilities.setNextCurrentCalendarMonth();
			setCalendar();
		},
		false
	);
}

function setCalendar() {
	let calendarMonth = commonUtilities.getCurrentCalendarMonth() + 1;
	if (calendarMonth < 10) {
		calendarMonth = "0" + calendarMonth;
	}
	
	fetch("https://api-web.nhle.com/v1/club-schedule/" + commonUtilities.getTeamAbbv() + "/month/" + commonUtilities.getCurrentCalendarYear() + "-" + calendarMonth)
		.catch(error => {
			return null;
		})
		.then(response => response.json())
		.then(calendarInfo => {
			setCalendarHeader();
			setCalendarDates(calendarInfo);
		});
}

function setPreview(gameInfo) {
	show(previewTab);
	hide(liveTab);
	hide(teamStatsTab);
	hide(playerStatsTab);
	show(standingsTab);
	
	setHeadingSection(gameInfo, "preview");
	setPlayerStatsSection(gameInfo, "preview");
	if (firstOpen) {
		setStandingsSection();
	}

	setActiveTab(playerStats, "Preview");
}

function setLive(gameInfo) {
	fetch("https://api-web.nhle.com/v1/gamecenter/" + gameInfo.id + "/play-by-play")
		.catch(error => {
			console.log(error);
		})
		.then(response => response.json())
		.then(liveData => {
			setRinkSection(liveData);
		});
	
	hide(previewTab);
	show(liveTab);
	hide(teamStatsTab); // Not coming through in the new API data
	show(playerStatsTab);
	show(standingsTab);
	
	setHeadingSection(gameInfo, "live");
	setTeamStatsSection(gameInfo);
	setPlayerStatsSection(gameInfo, "live");
	if (firstOpen) {
		setStandingsSection();
	}

	setActiveTab(rink, "Live");
}

function setFinal(gameInfo) {
	hide(previewTab);
	hide(liveTab);
	show(teamStatsTab);
	show(playerStatsTab);
	show(standingsTab);

	if (gameTimeDataRefreshTimer) {
		document.clearInterval(gameTimeDataRefreshTimer);
		gameTimeDataRefreshTimer = false;
	}
	
	setHeadingSection(gameInfo, "final");
	setTeamStatsSection(gameInfo);
	setPlayerStatsSection(gameInfo, "final");
	if (firstOpen) {
		setStandingsSection();
	}

	setActiveTab(teamStats, "Final");
}

function setNoGame() {
	hide(previewTab);
	hide(liveTab);
	hide(teamStatsTab);
	show(playerStatsTab);
	show(standingsTab);
	
	setHeadingSection(null, "none");
	setPlayerStatsSection(null, "none");
	if (firstOpen) {
		setStandingsSection();
	}

	setActiveTab(calendar, "None");
}

function setHeadingSection(gameData, gameStatus) {
	const headingAwayScore = document.getElementById("awayScore");
	const timeLeft = document.getElementById("time");
	const headingHomeScore = document.getElementById("homeScore");

	switch(gameStatus) {
		case "preview":
			drawAwayLogo(awayTeamIcon);
			drawHomeLogo(homeTeamIcon);
			var dateTime = new Date(gameData.startTimeUTC);
			timeLeft.innerHTML = "Puck Drop: " + getTimeZoneAdjustedTime(dateTime);
			headingAwayScore.innerHTML = "";
			headingHomeScore.innerHTML = "";
			break;
		case "live":
			drawAwayLogo(awayTeamIcon);
			drawHomeLogo(homeTeamIcon);
			var period = gameData.period;
			var isShootout = period === 5;
			switch (period) {
				case 1:
					period = "1st";
					break;
				case 2:
					period = "2nd";
					break;
				case 3:
					period = "3rd";
					break;
				case 4:
					period = "OT";
					break;
				case 5:
					period = "SO";
					break;
			}
			
			if (gameData.clock.inIntermission) {
				headingAwayScore.innerHTML = awayScore;
				headingHomeScore.innerHTML = homeScore;
				timeLeft.innerHTML = gameData.clock.timeRemaining + " / INT";
			} else {
				if (isShootout) {
					headingAwayScore.innerHTML = gameData.boxscore.linescore.shootout.awayConversions;
					headingHomeScore.innerHTML = gameData.boxscore.linescore.shootout.homeConversions;
					timeLeft.innerHTML = "SO";
				} else {
					headingAwayScore.innerHTML = awayScore;
					headingHomeScore.innerHTML = homeScore;
					timeLeft.innerHTML = gameData.clock.timeRemaining + " / " + period;
				}
			}
			startInGameDataUpdateTimerIfNeeded();
			break;
		case "final":
			drawAwayLogo(awayTeamIcon);
			drawHomeLogo(homeTeamIcon);
			timeLeft.innerHTML = "Final";
			headingAwayScore.innerHTML = awayScore;
			headingHomeScore.innerHTML = homeScore;
			break;
		case "none":
			drawAwayLogo(teamIcon);
			drawHomeLogo(teamIcon);
			timeLeft.innerHTML = "No Game";
			headingAwayScore.innerHTML = "";
			headingHomeScore.innerHTML = "";
			break;
	}
}

function setCalendarHeader() {
	const monthName = document.getElementById("monthName");
	monthName.innerHTML = commonUtilities.getCurrentCalendarMonthName() + " " + commonUtilities.getCurrentCalendarYear();
}

function setCalendarDates(calendarData) {
	clearCalendar();
	const currentYear = commonUtilities.getCurrentCalendarYear();
	const currentMonth = commonUtilities.getCurrentCalendarMonth();
	const firstDay = new Date(currentYear, currentMonth, 1).getDay();
	const lastDay = new Date(currentYear, currentMonth + 1, 0).getDate();
	const todayDate = new Date(commonUtilities.getTodayYear(), commonUtilities.getTodayMonth() - 1, commonUtilities.getTodayDay());
	const games = calendarData.games;

	for (let i = 1; i <= lastDay; i++) {
		const currentDate = firstDay + i;
		const calendarDay = document.getElementById("calendarDay" + currentDate);
		const calendarDate = document.getElementById("calendarDate" + currentDate);
		const calendarGameLogo = document.getElementById("calendarGameLogo" + currentDate);
		const calendarGameTime = document.getElementById("calendarGameTime" + currentDate);

		calendarDate.innerHTML = i;

		for (let j = 0; j < games.length; j++) {
			const gameDate = new Date(games[j].gameDate);

			if (gameDate.getDate() + 1 === i) {
				const gameData = games[j];
				let awayScore = gameData.awayTeam.score;
				let homeScore = gameData.homeTeam.score;
				let isHomeTeam = false;

				if (gameData.awayTeam.id === teamId) {
					isHomeTeam = false;
					calendarGameLogo.src = "logos/" + commonUtilities.getTeamNameAbbvMapping()[gameData.homeTeam.abbrev] + ".png";
					addClass(calendarDay, "awayGame");
				} else {
					isHomeTeam = true;
					calendarGameLogo.src = "logos/" + commonUtilities.getTeamNameAbbvMapping()[gameData.awayTeam.abbrev] + ".png";
					addClass(calendarDay, "homeGame");
				}

				if (gameData.gameState === "OFF") {
					const winOrLoss = isHomeTeam ? homeScore > awayScore ? "W" : "L" : awayScore > homeScore ? "W" : "L";
					calendarGameTime.innerHTML = awayScore + " - " + homeScore + " " + winOrLoss;
				} else if (gameData.gameState === "FUT") {
					const dateTime = new Date(gameData.startTimeUTC);
					calendarGameTime.innerHTML = getTimeZoneAdjustedTime(dateTime);
				} else if (gameData.gameState === "PPD") {
					calendarGameTime.innerHTML = "PPD";
				} else {
					calendarGameTime.innerHTML = awayScore + " - " + homeScore;
				}
				
				show(calendarGameLogo);
			}
		}
		
		if (currentYear === todayDate.getFullYear() && currentMonth === todayDate.getMonth() && todayDate.getDate() === i) {
			calendarDay.innerHTML += "<div class='today' id='today'></div>";
		}
	}
}

function clearCalendar() {
	for (let i = 1; i < 42; i++) {
		const calendarDay = document.getElementById("calendarDay" + i);
		const calendarDate = document.getElementById("calendarDate" + i);
		const calendarGameLogo = document.getElementById("calendarGameLogo" + i);
		const calendarGameTime = document.getElementById("calendarGameTime" + i);
		const today = document.getElementById("today");

		calendarDate.innerHTML = "";

		removeClass(calendarDay, "homeGame");
		removeClass(calendarDay, "awayGame");

		calendarGameTime.innerHTML = "";

		hide(calendarGameLogo);

		if (today && calendarDay.children.length == 3) {
			calendarDay.removeChild(today);
		}
	}
}

function setRinkSection(gameData) {
	const awayLeftWing = document.getElementById("awayLeftWing");
	const awayCenter = document.getElementById("awayCenter");
	const awayRightWing = document.getElementById("awayRightWing");
	const awayLeftDefense = document.getElementById("awayLeftDefense");
	const awayRightDefense = document.getElementById("awayRightDefense");
	const awayGoalie = document.getElementById("awayGoalie");
	const homeLeftWing = document.getElementById("homeLeftWing");
	const homeCenter = document.getElementById("homeCenter");
	const homeRightWing = document.getElementById("homeRightWing");
	const homeLeftDefense = document.getElementById("homeLeftDefense");
	const homeRightDefense = document.getElementById("homeRightDefense");
	const homeGoalie = document.getElementById("homeGoalie");

	// Live rink stats
	const awayOnIce = gameData.awayTeam.onIce;
	const homeOnIce = gameData.homeTeam.onIce;
	const rosterSpots = gameData.rosterSpots;

	if(awayTeamOnIce !== awayOnIce) {
		for(var i = 0; i < awayOnIce.length; i++) {
			const player = rosterSpots.find(rosterSpot => rosterSpot.playerId === awayOnIce[i].playerId);
			const fullName = player.firstName.default + " " + player.lastName.default;
			const sweaterNumber = player.sweaterNumber;
			
			switch(player.positionCode) {
				case "D":
					if(awayTeamDefense.length === 0) {
						awayTeamDefense.push(awayOnIce[i]);
						awayLeftDefense.innerHTML = sweaterNumber ?? 0;
						awayLeftDefense.setAttribute('title', fullName);
					} else if (awayTeamDefense.length === 1) {
						awayTeamDefense.push(awayOnIce[i]);
						awayRightDefense.innerHTML = sweaterNumber ?? 0;
						awayRightDefense.setAttribute('title', fullName);
					} else {
						if (!awayOnIce.includes(awayTeamDefense[0])) {
							awayTeamDefense = [awayOnIce[i], awayTeamDefense[1]];
							awayLeftDefense.innerHTML = sweaterNumber ?? 0;
							awayLeftDefense.setAttribute('title', fullName);
						} else if (!awayOnIce.includes(awayTeamDefense[1])) {
							awayTeamDefense = [awayTeamDefense[0], awayOnIce[i]];
							awayRightDefense.innerHTML = sweaterNumber ?? 0;
							awayRightDefense.setAttribute('title', fullName);
						}
					}
					break;
				case "G":
					if (awayGoalie.innerHTML !== sweaterNumber ?? 0) {
						awayGoalie.innerHTML = sweaterNumber ?? 0;
						awayGoalie.setAttribute('title', fullName);
					}
					break;
				default:
					if (awayTeamOffense.length < 3) {
						awayTeamOffense.push(awayOnIce[i]);
						if (awayTeamOffense.length === 0) {
							awayLeftWing.innerHTML = sweaterNumber ?? 0;
							awayLeftWing.setAttribute('title', fullName);
						} else if (awayTeamOffense.length === 1) {
							awayCenter.innerHTML = sweaterNumber ?? 0;
							awayCenter.setAttribute('title', fullName);
						} else if (awayTeamOffense.length === 2) {
							awayRightWing.innerHTML = sweaterNumber ?? 0;
							awayRightWing.setAttribute('title', fullName);
						}
					} else {
						if (!awayOnIce.includes(awayTeamOffense[0])) {
							awayTeamOffense = [awayOnIce[i], awayTeamOffense[1], awayTeamOffense[2]];
							awayLeftWing.innerHTML = sweaterNumber ?? 0;
							awayLeftWing.setAttribute('title', fullName);
						} else if (!awayOnIce.includes(awayTeamOffense[1])) {
							awayTeamOffense = [awayTeamOffense[0], awayOnIce[i], awayTeamOffense[2]];
							awayCenter.innerHTML = sweaterNumber ?? 0;
							awayCenter.setAttribute('title', fullName);
						} else if (!awayOnIce.includes(awayTeamOffense[2])) {
							awayTeamOffense = [awayTeamOffense[0], awayTeamOffense[1], awayOnIce[i]];
							awayRightWing.innerHTML = sweaterNumber ?? 0;
							awayRightWing.setAttribute('title', fullName);
						}
					}
					break;
			}
		}
		
		awayTeamOnIce = awayOnIce;
	}
	
	if(homeTeamOnIce !== homeOnIce) {
		for(var i = 0; i < homeOnIce.length; i++) {
			const player = rosterSpots.find(rosterSpot => rosterSpot.playerId === homeOnIce[i].playerId);
			const fullName = player.firstName.default + " " + player.lastName.default;
			const sweaterNumber = player.sweaterNumber;
			
			switch(player.positionCode) {
				case "D":
					if(homeTeamDefense.length === 0) {
						homeTeamDefense.push(homeOnIce[i]);
						homeLeftDefense.innerHTML = sweaterNumber ?? 0;
						homeLeftDefense.setAttribute('title', fullName);
					} else if (homeTeamDefense.length === 1) {
						homeTeamDefense.push(homeOnIce[i]);
						homeRightDefense.innerHTML = sweaterNumber ?? 0;
						homeRightDefense.setAttribute('title', fullName);
					} else {
						if (!homeOnIce.includes(homeTeamDefense[0])) {
							homeTeamDefense = [homeOnIce[i], homeTeamDefense[1]];
							homeLeftDefense.innerHTML = sweaterNumber ?? 0;
							homeLeftDefense.setAttribute('title', fullName);
						} else if (!homeOnIce.includes(homeTeamDefense[1])) {
							homeTeamDefense = [homeTeamDefense[0], homeOnIce[i]];
							homeRightDefense.innerHTML = sweaterNumber ?? 0;
							homeRightDefense.setAttribute('title', fullName);
						}
					}
					break;
				case "G":
					if (homeGoalie.innerHTML !== sweaterNumber ?? 0) {
						homeGoalie.innerHTML = sweaterNumber ?? 0;
						homeGoalie.setAttribute('title', fullName);
					}
					break;
				default:
					if (homeTeamOffense.length < 3) {
						homeTeamOffense.push(homeOnIce[i]);
						if (homeTeamOffense.length === 0) {
							homeLeftWing.innerHTML = sweaterNumber ?? 0;
							homeLeftWing.setAttribute('title', fullName);
						} else if (homeTeamOffense.length === 1) {
							homeCenter.innerHTML = sweaterNumber ?? 0;
							homeCenter.setAttribute('title', fullName);
						} else if (homeTeamOffense.length === 2) {
							homeRightWing.innerHTML = sweaterNumber ?? 0;
							homeRightWing.setAttribute('title', fullName);
						}
					} else {
						if (!homeOnIce.includes(homeTeamOffense[0])) {
							homeTeamOffense = [homeOnIce[i], homeTeamOffense[1], homeTeamOffense[2]];
							homeLeftWing.innerHTML = sweaterNumber ?? 0;
							homeLeftWing.setAttribute('title', fullName);
						} else if (!homeOnIce.includes(homeTeamOffense[1])) {
							homeTeamOffense = [homeTeamOffense[0], homeOnIce[i], homeTeamOffense[2]];
							homeCenter.innerHTML = sweaterNumber ?? 0;
							homeCenter.setAttribute('title', fullName);
						} else if (!homeOnIce.includes(homeTeamOffense[2])) {
							homeTeamOffense = [homeTeamOffense[0], homeTeamOffense[1], homeOnIce[i]];
							homeRightWing.innerHTML = sweaterNumber ?? 0;
							homeRightWing.setAttribute('title', fullName);
						}
					}
					break;
			}
		}
		
		homeTeamOnIce = homeOnIce;
	}
}

function setTeamStatsSection(gameData) {
	// Teams
	const teamStatsAwayImage = document.getElementById("teamStatsAwayImage");
	const teamStatsAwayTeamName = document.getElementById("teamStatsAwayTeamName");
	const teamStatsHomeImage = document.getElementById("teamStatsHomeImage");
	const teamStatsHomeTeamName = document.getElementById("teamStatsHomeTeamName");
	
	// Away Team
	const awayTeamSOG = document.getElementById("awayTeamSOG");
	const awayTeamFO = document.getElementById("awayTeamFO");
	const awayTeamPPG = document.getElementById("awayTeamPPG");
	const awayTeamPIM = document.getElementById("awayTeamPIM");
	const awayTeamHITS = document.getElementById("awayTeamHITS");
	const awayTeamBLKS = document.getElementById("awayTeamBLKS");
	const awayTeamGVA = document.getElementById("awayTeamGVA");
	
	// Home Team
	const homeTeamSOG = document.getElementById("homeTeamSOG");
	const homeTeamFO = document.getElementById("homeTeamFO");
	const homeTeamPPG = document.getElementById("homeTeamPPG");
	const homeTeamPIM = document.getElementById("homeTeamPIM");
	const homeTeamHITS = document.getElementById("homeTeamHITS");
	const homeTeamBLKS = document.getElementById("homeTeamBLKS");
	const homeTeamGVA = document.getElementById("homeTeamGVA");
	
	// Live in-game stats
	teamStatsAwayImage.src = awayTeamIcon;
	teamStatsHomeImage.src = homeTeamIcon;
	teamStatsAwayTeamName.innerHTML = awayTeamName;
	teamStatsHomeTeamName.innerHTML = homeTeamName;

	const awayTeamStats = gameData.awayTeam;
	awayTeamSOG.innerHTML = awayTeamStats.sog;
	awayTeamFO.innerHTML = awayTeamStats.faceoffWinningPctg;
	awayTeamPPG.innerHTML = awayTeamStats.powerPlayConversion;
	awayTeamPIM.innerHTML = awayTeamStats.pim;
	awayTeamHITS.innerHTML = awayTeamStats.hits;
	awayTeamBLKS.innerHTML = awayTeamStats.blocks;
	// awayTeamGVA.innerHTML = awayTeamStats.giveaways; Not in new version of API
	
	const homeTeamStats = gameData.homeTeam;
	homeTeamSOG.innerHTML = homeTeamStats.sog;
	homeTeamFO.innerHTML = homeTeamStats.faceoffWinningPctg;
	homeTeamPPG.innerHTML = homeTeamStats.powerPlayConversion;
	homeTeamPIM.innerHTML = homeTeamStats.pim;
	homeTeamHITS.innerHTML = homeTeamStats.hits;
	homeTeamBLKS.innerHTML = homeTeamStats.blocks;
	// homeTeamGVA.innerHTML = homeTeamStats.giveaways; Not in new version of API
}

function setPlayerStatsSection(gameData, gameStatus) {
	if (gameStatus === "preview") {
		const awayPlayerStatsTeamName = document.getElementById("awayPlayerStatsTeamName");
		const homePlayerStatsTeamName = document.getElementById("homePlayerStatsTeamName");
		awayPlayerStatsTeamName.innerHTML = awayTeamName;
		homePlayerStatsTeamName.innerHTML = homeTeamName;

		const awayTeamPlayerStats = document.getElementById("awayTeamPlayerStats");
		const homeTeamPlayerStats = document.getElementById("homeTeamPlayerStats");
		const awayStatsButton = document.getElementById("awayStatsButton");
		const homeStatsButton = document.getElementById("homeStatsButton");
		awayStatsButton.addEventListener('click', function () {
			hide(homeTeamPlayerStats);
			removeClass(homeStatsButton, "selected");
			show(awayTeamPlayerStats);
			addClass(awayStatsButton, "selected");
		}, false);
		homeStatsButton.addEventListener('click', function () {
			hide(awayTeamPlayerStats);
			removeClass(awayStatsButton, "selected");
			show(homeTeamPlayerStats);
			addClass(homeStatsButton, "selected");
		}, false);
		
		const awayTeamAbbv = commonUtilities.getTeamAbbvs()[awayTeamName];
		fetch("https://api-web.nhle.com/v1/club-stats/" + awayTeamAbbv + "/now")
			.catch(error => {
				console.log(error);
			})
			.then(response => response.json())
			.then(playerStats => {
				setAwayNonLivePlayerStats(playerStats, awayTeamAbbv);
			});
		
		const homeTeamAbbv = commonUtilities.getTeamAbbvs()[homeTeamName];
		fetch("https://api-web.nhle.com/v1/club-stats/" + homeTeamAbbv + "/now")
			.catch(error => {
				console.log(error);
			})
			.then(response => response.json())
			.then(playerStats => {
				setHomeNonLivePlayerStats(playerStats, homeTeamAbbv);
			});
	} else if (gameStatus === "live" || gameStatus === "final") {
		const inGamePlayerStats = document.getElementById("inGamePlayerStats");

		const inGameAwayStatsButton = document.getElementById("inGameAwayStatsButton");
		const inGameHomeStatsButton = document.getElementById("inGameHomeStatsButton");
		const inGameAwayTeam = document.getElementById("inGameAwayTeam");
		const inGameHomeTeam = document.getElementById("inGameHomeTeam");
		inGameAwayStatsButton.addEventListener('click', function () {
			hide(inGameHomeTeam);
			removeClass(inGameHomeStatsButton, "selected");
			show(inGameAwayTeam);
			addClass(inGameAwayStatsButton, "selected");
		}, false);
		inGameHomeStatsButton.addEventListener('click', function () {
			hide(inGameAwayTeam);
			removeClass(inGameAwayStatsButton, "selected");
			show(inGameHomeTeam);
			addClass(inGameHomeStatsButton, "selected");
		}, false);

		const inGameAwayPlayerStatsTeamName = document.getElementById("inGameAwayPlayerStatsTeamName");
		const inGameHomePlayerStatsTeamName = document.getElementById("inGameHomePlayerStatsTeamName");
		inGameAwayStatsButton.innerHTML = awayTeamName;
		inGameHomeStatsButton.innerHTML = homeTeamName;
		inGameAwayPlayerStatsTeamName.innerHTML = awayTeamName;
		inGameHomePlayerStatsTeamName.innerHTML = homeTeamName;

		const inGameAwayTeamForwards = document.getElementById("inGameAwayTeamForwards");
		const inGameAwayTeamDefense = document.getElementById("inGameAwayTeamDefense");
		const inGameAwayTeamGoalies = document.getElementById("inGameAwayTeamGoalies");
		clearElement(inGameAwayTeamForwards);
		clearElement(inGameAwayTeamDefense);
		clearElement(inGameAwayTeamGoalies);

		const inGameHomeTeamForwards = document.getElementById("inGameHomeTeamForwards");
		const inGameHomeTeamDefense = document.getElementById("inGameHomeTeamDefense");
		const inGameHomeTeamGoalies = document.getElementById("inGameHomeTeamGoalies");
		clearElement(inGameHomeTeamForwards);
		clearElement(inGameHomeTeamDefense);
		clearElement(inGameHomeTeamGoalies);
		
		const awayTeamPlayers = gameData.boxscore.playerByGameStats.awayTeam;
		const homeTeamPlayers = gameData.boxscore.playerByGameStats.homeTeam;
		
		for(let i = 0; i < awayTeamPlayers.forwards.length; i++) {
			addInGamePlayerStat(awayTeamPlayers.forwards[i], inGameAwayTeamForwards);
		}
		
		for(let i = 0; i < awayTeamPlayers.defense.length; i++) {
			addInGamePlayerStat(awayTeamPlayers.defense[i], inGameAwayTeamDefense);
		}
		
		for(let i = 0; i < awayTeamPlayers.goalies.length; i++) {
			addInGamePlayerStat(awayTeamPlayers.goalies[i], inGameAwayTeamGoalies, true);
		}
		
		for(let i = 0; i < homeTeamPlayers.forwards.length; i++) {
			addInGamePlayerStat(homeTeamPlayers.forwards[i], inGameHomeTeamForwards);
		}
		
		for(let i = 0; i < homeTeamPlayers.defense.length; i++) {
			addInGamePlayerStat(homeTeamPlayers.defense[i], inGameHomeTeamDefense);
		}
		
		for(let i = 0; i < homeTeamPlayers.goalies.length; i++) {
			addInGamePlayerStat(homeTeamPlayers.goalies[i], inGameHomeTeamGoalies, true);
		}
	} else {
		fetch("https://api-web.nhle.com/v1/club-stats/" + commonUtilities.getTeamAbbv() + "/now")
			.catch(error => {
				console.log(error);
			})
			.then(response => response.json())
			.then(playerStats => {
				setNonLivePlayerStats(playerStats);
			});
	}
}

function setAwayNonLivePlayerStats(playerStats, teamAbbv) {
	const awayTeamForwards = document.getElementById("awayTeamForwards");
	const awayTeamDefense = document.getElementById("awayTeamDefense");
	const awayTeamGoalies = document.getElementById("awayTeamGoalies");
	clearElement(awayTeamForwards);
	clearElement(awayTeamDefense);
	clearElement(awayTeamGoalies);
	
	let rosterData = null;
	fetch("https://api-web.nhle.com/v1/roster/" + teamAbbv + "/current")
		.catch(error => {
			console.log(error);
		})
		.then(response => response.json())
		.then(rosterInfo => addPlayerStats(playerStats, rosterInfo, awayTeamDefense, awayTeamForwards, awayTeamGoalies));
}

function setHomeNonLivePlayerStats(playerStats, teamAbbv) {
	const homeTeamForwards = document.getElementById("homeTeamForwards");
	const homeTeamDefense = document.getElementById("homeTeamDefense");
	const homeTeamGoalies = document.getElementById("homeTeamGoalies");
	clearElement(homeTeamForwards);
	clearElement(homeTeamDefense);
	clearElement(homeTeamGoalies);
	
	fetch("https://api-web.nhle.com/v1/roster/" + teamAbbv + "/current")
		.catch(error => {
			console.log(error);
		})
		.then(response => response.json())
		.then(rosterInfo => addPlayerStats(playerStats, rosterInfo, homeTeamDefense, homeTeamForwards, homeTeamGoalies));
}

function setNonLivePlayerStats(playerStats) {
	const noGamePlayerStatsTeamName = document.getElementById("noGamePlayerStatsTeamName");
	noGamePlayerStatsTeamName.innerHTML = teamName;

	const noGamePlayerStats = document.getElementById("noGamePlayerStats");
	const teamForwards = document.getElementById("noGameForwards");
	const teamDefense = document.getElementById("noGameDefense");
	const teamGoalies = document.getElementById("noGameGoalies");
	clearElement(teamForwards);
	clearElement(teamDefense);
	clearElement(teamGoalies);
	
	fetch("https://api-web.nhle.com/v1/roster/" + commonUtilities.getTeamAbbv() + "/current")
		.catch(error => {
			console.log(error);
		})
		.then(response => response.json())
		.then(rosterInfo => addPlayerStats(playerStats, rosterInfo, teamDefense, teamForwards, teamGoalies));
}

function addPlayerStats(playerStats, rosterData, defenseElement, forwardsElement, goaliesElement) {
	for(let i = 0; i < playerStats.skaters.length; i++) {
		const player = playerStats.skaters[i];
		if (player.positionCode === "D") {
			addPlayerStat(player, defenseElement, false, rosterData.defensemen.find(defenseman => defenseman.lastName.default === player.lastName.default && defenseman.firstName.default === player.firstName.default)?.sweaterNumber);
		} else {
			addPlayerStat(player, forwardsElement, false, rosterData.forwards.find(forward => forward.lastName.default === player.lastName.default && forward.firstName.default === player.firstName.default)?.sweaterNumber);
		}
	}
	
	for(let i = 0; i < playerStats.goalies.length; i++) {
		const player = playerStats.goalies[i];
		addPlayerStat(player, goaliesElement, true, rosterData.goalies.find(goalie => goalie.lastName.default === player.lastName.default && goalie.firstName.default === player.firstName.default)?.sweaterNumber);
	}
}

function setStandingsSection() {
	const divisionStandings = document.getElementById("divisionStandings");
	const wildCardStandings = document.getElementById("wildCardStandings");
	const conferenceStandings = document.getElementById("conferenceStandings");
	const leagueStandings = document.getElementById("leagueStandings");

	const divisionStandingsButton = document.getElementById("divisionStandingsButton");
	const wildCardStandingsButton = document.getElementById("wildCardStandingsButton");
	const conferenceStandingsButton = document.getElementById("conferenceStandingsButton");
	const leagueStandingsButton = document.getElementById("leagueStandingsButton");
	divisionStandingsButton.addEventListener('click', function () {
		hide(wildCardStandings);
		hide(conferenceStandings);
		hide(leagueStandings);
		removeClass(wildCardStandingsButton, "selected");
		removeClass(conferenceStandingsButton, "selected");
		removeClass(leagueStandingsButton, "selected");
		show(divisionStandings);
		addClass(divisionStandingsButton, "selected");
	}, false);
	wildCardStandingsButton.addEventListener('click', function () {
		hide(divisionStandings);
		hide(conferenceStandings);
		hide(leagueStandings);
		removeClass(divisionStandingsButton, "selected");
		removeClass(conferenceStandingsButton, "selected");
		removeClass(leagueStandingsButton, "selected");
		show(wildCardStandings);
		addClass(wildCardStandingsButton, "selected");
	}, false);
	conferenceStandingsButton.addEventListener('click', function () {
		hide(divisionStandings);
		hide(wildCardStandings);
		hide(leagueStandings);
		removeClass(divisionStandingsButton, "selected");
		removeClass(wildCardStandingsButton, "selected");
		removeClass(leagueStandingsButton, "selected");
		show(conferenceStandings);
		addClass(conferenceStandingsButton, "selected");
	}, false);
	leagueStandingsButton.addEventListener('click', function () {
		hide(divisionStandings);
		hide(wildCardStandings);
		hide(conferenceStandings);
		removeClass(divisionStandingsButton, "selected");
		removeClass(wildCardStandingsButton, "selected");
		removeClass(conferenceStandingsButton, "selected");
		show(leagueStandings);
		addClass(leagueStandingsButton, "selected");
	}, false);
	
	fetch("https://api-web.nhle.com/v1/standings/now")
		.catch(error => {
			console.log(error);
		})
		.then(response => response.json())
		.then(standingsInfo => {
			setStandingsData(standingsInfo.standings);
		});
}

function setFooterLinkHref(gameStatus, currentGameId, awayTeamInitial, homeTeamInitial) {
	const nhlLink = document.getElementById("nhlLink");
	switch(gameStatus) {
		case "preview":
			nhlLink.setAttribute("href", "http://www.nhl.com/gamecenter/" + awayTeamInitial + "-vs-" + homeTeamInitial + "/" + todayYear + "/" + todayMonth + "/" + todayDay + "/" + currentGameId + "#game=" + currentGameId + ",game_state=preview");
			break;
		case "live":
			nhlLink.setAttribute("href", "http://www.nhl.com/gamecenter/" + awayTeamInitial + "-vs-" + homeTeamInitial + "/" + todayYear + "/" + todayMonth + "/" + todayDay + "/" + currentGameId + "#game=" + currentGameId + ",game_state=live,game_tab=live");
			break;
		case "final":
			nhlLink.setAttribute("href", "http://www.nhl.com/gamecenter/" + awayTeamInitial + "-vs-" + homeTeamInitial + "/" + todayYear + "/" + todayMonth + "/" + todayDay + "/" + currentGameId + "#game=" + currentGameId + ",game_state=live,game_tab=live");
			break;
		case "none":
			nhlLink.setAttribute("href", "https://www.nhl.com/scores");
			break;
	}
}

function addInGamePlayerStat(player, element, isGoalie = false) {
	const playerName = player.name.default.split(" ");
	const statLine = document.createElement("div");
	addClass(statLine, "playerStatsLine");

	const nameNumber = document.createElement("div");
	addClass(nameNumber, "nameNumber");
	const number = document.createElement("div");
	addClass(number, "number");
	number.innerHTML = player.sweaterNumber ?? 0;
	const name = document.createElement("div");
	addClass(name, "name");
	name.innerHTML = playerName[playerName.length - 1];
	nameNumber.appendChild(number);
	nameNumber.appendChild(name);
	statLine.appendChild(nameNumber);

	const stats = document.createElement("div");
	addClass(stats, "stats");

	if (!isGoalie) {
		const shots = document.createElement("div");
		addClass(shots, "stat");
		shots.innerHTML = player.shots;
		stats.appendChild(shots);
		const goals = document.createElement("div");
		addClass(goals, "stat");
		goals.innerHTML = player.goals;
		stats.appendChild(goals);
		const assists = document.createElement("div");
		addClass(assists, "stat");
		assists.innerHTML = player.assists;
		stats.appendChild(assists);
		const points = document.createElement("div");
		addClass(points, "stat");
		points.innerHTML = player.points;
		stats.appendChild(points);
		const plusMinus = document.createElement("div");
		addClass(plusMinus, "stat");
		plusMinus.innerHTML = player.plusMinus;
		stats.appendChild(plusMinus);
		const penaltyMinutes = document.createElement("div");
		addClass(penaltyMinutes, "stat");
		penaltyMinutes.innerHTML = player.pim;
		stats.appendChild(penaltyMinutes);
		const powerPlay = document.createElement("div");
		addClass(powerPlay, "stat");
		powerPlay.innerHTML = player.powerPlayGoals;
		stats.appendChild(powerPlay);
		const shortHanded = document.createElement("div");
		addClass(shortHanded, "stat");
		shortHanded.innerHTML = player.shorthandedGoals;
		stats.appendChild(shortHanded);
	} else {
		const evenShotsAgainst = document.createElement("div");
		addClass(evenShotsAgainst, "stat");
		evenShotsAgainst.innerHTML = player.evenStrengthShotsAgainst;
		stats.appendChild(evenShotsAgainst);
		const powerPlayShotsAgainst = document.createElement("div");
		addClass(powerPlayShotsAgainst, "stat");
		powerPlayShotsAgainst.innerHTML = player.powerPlayShotsAgainst;
		stats.appendChild(powerPlayShotsAgainst);
		const shortHandedShotsAgainst = document.createElement("div");
		addClass(shortHandedShotsAgainst, "stat");
		shortHandedShotsAgainst.innerHTML = player.shorthandedShotsAgainst;
		stats.appendChild(shortHandedShotsAgainst);
		const savesShotsAgainst = document.createElement("div");
		addClass(savesShotsAgainst, "stat");
		addClass(savesShotsAgainst, "savesShots");
		savesShotsAgainst.innerHTML = player.saveShotsAgainst;
		stats.appendChild(savesShotsAgainst);
		const savePercent = document.createElement("div");
		addClass(savePercent, "stat");
		let savePercentText = Number(player.savePctg ?? 0) * 100;
		savePercent.innerHTML = savePercentText.toFixed(2) + "%";
		stats.appendChild(savePercent);
		const penaltyMinutes = document.createElement("div");
		addClass(penaltyMinutes, "stat");
		const penaltyMinutesStat = player.pim;
		penaltyMinutes.innerHTML = penaltyMinutesStat ? penaltyMinutesStat : 0;
		stats.appendChild(penaltyMinutes);
		const timeOnIce = document.createElement("div");
		addClass(timeOnIce, "stat");
		timeOnIce.innerHTML = player.toi;
		stats.appendChild(timeOnIce);
	}

	statLine.appendChild(stats);
	element.appendChild(statLine);
}

function addPlayerStat(player, element, isGoalie = false, sweaterNumber = 0) {
	let playerName = "";
	if (player.lastName) {
		playerName = player.lastName.default;
	} else {
		playerName = player.name.default;
	}
	
	const statLine = document.createElement("div");
	addClass(statLine, "playerStatsLine");

	const nameNumber = document.createElement("div");
	addClass(nameNumber, "nameNumber");
	const number = document.createElement("div");
	addClass(number, "number");
	number.innerHTML = sweaterNumber;
	const name = document.createElement("div");
	addClass(name, "name");
	name.innerHTML = playerName;
	nameNumber.appendChild(number);
	nameNumber.appendChild(name);
	statLine.appendChild(nameNumber);

	const statsElement = document.createElement("div");
	addClass(statsElement, "stats");

	if (!isGoalie) {
		const games = document.createElement("div");
		addClass(games, "stat");
		const gamesStat = player.gamesPlayed;
		games.innerHTML = gamesStat ? gamesStat : 0;
		statsElement.appendChild(games);
		const goals = document.createElement("div");
		addClass(goals, "stat");
		const goalsStat = player.goals;
		goals.innerHTML = goalsStat ? goalsStat : 0;
		statsElement.appendChild(goals);
		const assists = document.createElement("div");
		addClass(assists, "stat");
		const assistsStat = player.assists;
		assists.innerHTML = assistsStat ? assistsStat : 0;
		statsElement.appendChild(assists);
		const points = document.createElement("div");
		addClass(points, "stat");
		points.innerHTML = assistsStat && goalsStat ? assistsStat + goalsStat : 0;
		statsElement.appendChild(points);
		const plusMinus = document.createElement("div");
		addClass(plusMinus, "stat");
		const plusMinusStat = player.plusMinus;
		plusMinus.innerHTML = plusMinusStat ? plusMinusStat : 0;
		statsElement.appendChild(plusMinus);
		const penaltyMinutes = document.createElement("div");
		addClass(penaltyMinutes, "stat");
		const penaltyMinutesStat = player.penaltyMinutes;
		penaltyMinutes.innerHTML = penaltyMinutesStat ? penaltyMinutesStat : 0;
		statsElement.appendChild(penaltyMinutes);
		const powerPlay = document.createElement("div");
		addClass(powerPlay, "stat");
		const powerPlayStat = player.powerPlayGoals;
		powerPlay.innerHTML = powerPlayStat ? powerPlayStat : 0;
		statsElement.appendChild(powerPlay);
		const gameWinning = document.createElement("div");
		addClass(gameWinning, "stat");
		const gameWinningStat = player.gameWinningGoals;
		gameWinning.innerHTML = gameWinningStat ? gameWinningStat : 0;
		statsElement.appendChild(gameWinning);
	} else {
		const games = document.createElement("div");
		addClass(games, "stat");
		const gamesStat = player.gamesPlayed;
		games.innerHTML = gamesStat ? gamesStat : 0;
		statsElement.appendChild(games);
		const wins = document.createElement("div");
		addClass(wins, "stat");
		const winsStat = player.wins;
		wins.innerHTML = winsStat ? winsStat : 0;
		statsElement.appendChild(wins);
		const losses = document.createElement("div");
		addClass(losses, "stat");
		const lossesStat = player.losses;
		losses.innerHTML = lossesStat ? lossesStat : 0;
		statsElement.appendChild(losses);
		const shotsAgainst = document.createElement("div");
		addClass(shotsAgainst, "stat");
		const shotsAgainstStat = player.shotsAgainst;
		shotsAgainst.innerHTML = shotsAgainstStat ? shotsAgainstStat : 0;
		statsElement.appendChild(shotsAgainst);
		const goalsAgainst = document.createElement("div");
		addClass(goalsAgainst, "stat");
		const goalsAgainstStat = player.goalsAgainst;
		goalsAgainst.innerHTML = goalsAgainstStat ? goalsAgainstStat : 0;
		statsElement.appendChild(goalsAgainst);
		const goalAgainstAverage = document.createElement("div");
		addClass(goalAgainstAverage, "stat");
		const goalsAgainstAverageStat = player.goalsAgainstAverage;
		goalAgainstAverage.innerHTML = goalsAgainstAverageStat.toFixed(2);
		statsElement.appendChild(goalAgainstAverage);
		const savePercent = document.createElement("div");
		addClass(savePercent, "stat");
		const savePercentageStat = Number(player.savePercentage) * 100;
		savePercent.innerHTML = savePercentageStat.toFixed(2) + "%";
		statsElement.appendChild(savePercent);
		const shutouts = document.createElement("div");
		addClass(shutouts, "stat");
		const shutoutsStat = player.shutouts;
		shutouts.innerHTML = shutoutsStat ? shutoutsStat : 0;
		statsElement.appendChild(shutouts);
	}

	statLine.appendChild(statsElement);
	element.appendChild(statLine);
}

function setStandingsData(standingsData) {
	const divisionTeamStandings = document.getElementById("divisionTeamStandings");
	const conferenceTeamStandings = document.getElementById("conferenceTeamStandings");
	const leagueTeamStandings = document.getElementById("leagueTeamStandings");
	clearElement(divisionTeamStandings);
	clearElement(conferenceTeamStandings);
	clearElement(leagueTeamStandings);
	
	setDivisionData(standingsData, divisionTeamStandings);
	setConferenceData(standingsData, conferenceTeamStandings);
	setLeagueData(standingsData, leagueTeamStandings);
}

function setDivisionData(standingsData, divisionElement) {
	const divisionTeams = [];
	for (let i = 0; i < standingsData.length; i++) {
		const standing = standingsData[i];
		if (standing.divisionAbbrev === commonUtilities.getTeamDivisionAbbv()) {
			divisionTeams.push(standing);
		}
	}
	
	addDivisionLines(divisionTeams, divisionElement);
	
	const conferenceTeams = [];
	for (let i = 0; i < standingsData.length; i++) {
		const standing = standingsData[i];
		if (standing.conferenceAbbrev === commonUtilities.getTeamConferenceAbbv()) {
			conferenceTeams.push(standing);
		}
	}
	
	const wildCardDivision1 = [];
	for (let i = 0; i < conferenceTeams.length; i++) {
		const standing = conferenceTeams[i];
		if (standing.divisionAbbrev === commonUtilities.getTeamDivisionAbbv()) {
			wildCardDivision1.push(standing);
		}
	}
	
	const wildCardDivision2 = [];
	for (let i = 0; i < conferenceTeams.length; i++) {
		const standing = conferenceTeams[i];
		if (standing.divisionAbbrev !== commonUtilities.getTeamDivisionAbbv()) {
			wildCardDivision2.push(standing);
		}
	}
	
	addWildCardLines(conferenceTeams, wildCardDivision1, wildCardDivision2);
}

function addDivisionLines(divisionTeams, element) {
	const divisionElement = document.getElementById("division");
	divisionElement.innerHTML = divisionTeams[0].divisionName;
	for (let i = 0; i < divisionTeams.length; i++) {
		addStandingsLine(divisionTeams[i], element);
	}
}

function addWildCardLines(conferenceTeams, division1Teams, division2Teams) {
	const wildCardDivision = document.getElementById("wildCardDivision");
	const wildCardDivision2 = document.getElementById("wildCardDivision2");
	wildCardDivision.innerHTML = division1Teams[0].divisionName;
	wildCardDivision2.innerHTML = division2Teams[0].divisionName;

	const wildCardDivisionLeadersTeamStandings = document.getElementById("wildCardDivisionLeadersTeamStandings");
	const wildCardDivision2LeadersTeamStandings = document.getElementById("wildCardDivision2LeadersTeamStandings");
	const wildCardTop2TeamStandings = document.getElementById("wildCardTop2TeamStandings");
	const wildCardTeamStandings = document.getElementById("wildCardTeamStandings");
	clearElement(wildCardDivisionLeadersTeamStandings);
	clearElement(wildCardDivision2LeadersTeamStandings);
	clearElement(wildCardTop2TeamStandings);
	clearElement(wildCardTeamStandings);

	for (let i = 0; i < division1Teams.length; i++) {
		const team = division1Teams[i];
		if (team.wildcardSequence === 0) {
			addStandingsLine(team, wildCardDivisionLeadersTeamStandings);
		}
	}
	for (let i = 0; i < division2Teams.length; i++) {
		const team = division2Teams[i];
		if (team.wildcardSequence === 0) {
			addStandingsLine(team, wildCardDivision2LeadersTeamStandings);
		}
	}

	for (let i = 0; i < conferenceTeams.length; i++) {
		const team = conferenceTeams[i];
		if (team.wildcardSequence === 0) {
			continue;
		} else if (team.wildcardSequence === 1) {
			addStandingsLine(team, wildCardTop2TeamStandings);
		} else if (team.wildcardSequence === 2) {
			addStandingsLine(team, wildCardTop2TeamStandings);
		} else {
			addStandingsLine(team, wildCardTeamStandings);
		}
	}
}

function setConferenceData(standingsData, conferenceElement) {
	const conferenceTeams = [];
	for (let i = 0; i < standingsData.length; i++) {
		const standing = standingsData[i];
		if (standing.conferenceAbbrev === commonUtilities.getTeamConferenceAbbv()) {
			conferenceTeams.push(standing);
		}
	}
	
	const conferenceTitleElement = document.getElementById("conference");
	conferenceTitleElement.innerHTML = conferenceTeams[0].conferenceName;
	
	for (let i = 0; i < conferenceTeams.length; i++) {
		addStandingsLine(conferenceTeams[i], conferenceElement);
	}
}

function setLeagueData(standingsData, leagueElement) {
	for (let i = 0; i < standingsData.length; i++) {
		addStandingsLine(standingsData[i], leagueElement);
	}
}

function addStandingsLine(team, element) {
	const statLine = document.createElement("div");
	addClass(statLine, "standingsTeamLine");

	var shortName = commonUtilities.getTeamNameAbbvMapping()[team.teamAbbrev.default];

	const standingsTeam = document.createElement("div");
	addClass(standingsTeam, "standingsTeam");
	const image = document.createElement("img");
	addClass(image, "standingsTeamImage");
	image.src = "logos/" + shortName + ".png";
	const name = document.createElement("div");
	addClass(name, "standingsTeamName");
	name.innerHTML = shortName;
	standingsTeam.appendChild(image);
	standingsTeam.appendChild(name);
	statLine.appendChild(standingsTeam);

	const statsElement = document.createElement("div");
	addClass(statsElement, "stats");

	const games = document.createElement("div");
	addClass(games, "stat");
	games.innerHTML = team.gamesPlayed;
	statsElement.appendChild(games);
	const wins = document.createElement("div");
	addClass(wins, "stat");
	wins.innerHTML = team.wins;
	statsElement.appendChild(wins);
	const losses = document.createElement("div");
	addClass(losses, "stat");
	losses.innerHTML = team.losses;
	statsElement.appendChild(losses);
	const overtime = document.createElement("div");
	addClass(overtime, "stat");
	overtime.innerHTML = team.otLosses;
	statsElement.appendChild(overtime);
	const points = document.createElement("div");
	addClass(points, "stat");
	points.innerHTML = team.points;
	statsElement.appendChild(points);
	const row = document.createElement("div");
	addClass(row, "stat");
	row.innerHTML = team.regulationPlusOtWins;
	statsElement.appendChild(row);
	const streak = document.createElement("div");
	addClass(streak, "stat");
	let streakCode = "-";
	if (team.streakCode) {
		streakCode = "" + team.streakCode + team.streakCount;
	}
	
	streak.innerHTML = streakCode !== null ? streakCode : "-";
	statsElement.appendChild(streak);

	statLine.appendChild(statsElement);
	element.appendChild(statLine);
}

function getTimeZoneAdjustedTime(dateTime) {
	const timeZone = commonUtilities.getTimeZone();
	var timeInGivenZone = new Date(dateTime.toLocaleString('en-US', {timeZone: timeZone}));
	var hours = parseInt(timeInGivenZone.getHours());
	var minutes = parseInt(timeInGivenZone.getMinutes());
	var pmAm = "AM";
	if (hours >= 12) {
		if (hours > 12) {
			hours -= 12;
		}
		pmAm = "PM";
	}
	if (minutes < 10) {
		minutes = "0" + minutes;
	}

	var localTime = hours + ":" + minutes + pmAm;
	if (localTime[0] == '0') {
		localTime = localTime.substring(1);
	}
	return localTime;
}

function drawAwayLogo(icon) {
	const headingAwayImage = document.getElementById("headingAwayImage");
	headingAwayImage.src = icon;
}

function drawHomeLogo(icon) {
	const headingHomeImage = document.getElementById("headingHomeImage");
	headingHomeImage.src = icon;
}

function setActiveTab(elementToShow, gameStatusToCheck) {
	if (firstOpen && gameStatus == gameStatusToCheck) {
		hideShowElements(elementToShow);
		firstOpen = false;
	}
	if (!firstOpen && gameStatus != gameStatusToCheck) {
		hideShowElements(elementToShow);
	}
}

function hideShowElements(elementToShow) {
	if (calendar === elementToShow) {
		show(calendar);
	} else {
		hide(calendar);
	}

	if (rink === elementToShow) {
		show(rink);
		addClass(liveTab, 'tabSelected');
	} else {
		hide(rink);
		removeClass(liveTab, 'tabSelected');
	}

	if (teamStats === elementToShow) {
		show(teamStats);
		addClass(teamStatsTab, 'tabSelected');
	} else {
		hide(teamStats);
		removeClass(teamStatsTab, 'tabSelected');
	}
	
	if (inGamePlayerStats === elementToShow) {
		show(inGamePlayerStats);
	} else {
		hide(inGamePlayerStats);
	}

	if (playerStats === elementToShow) {
		show(playerStats);
		if (gameStatus === "Preview") {
			addClass(previewTab, 'tabSelected');
		}
	} else {
		hide(playerStats);
		if (gameStatus === "Preview") {
			removeClass(previewTab, 'tabSelected');
		}
	}
	
	if (noGamePlayerStats === elementToShow) {
		show(noGamePlayerStats);
	} else {
		hide(noGamePlayerStats);
	}
	
	if (inGamePlayerStats === elementToShow || playerStats === elementToShow || noGamePlayerStats === elementToShow) {
		addClass(playerStatsTab, 'tabSelected');
	} else {
		removeClass(playerStatsTab, 'tabSelected');
	}

	if (standings === elementToShow) {
		show(standings);
		addClass(standingsTab, 'tabSelected');
	} else {
		hide(standings);
		removeClass(standingsTab, 'tabSelected');
	}
}