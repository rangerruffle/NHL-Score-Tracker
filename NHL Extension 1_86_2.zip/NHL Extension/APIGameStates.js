const APIGameStates = {
	CRITICAL: "CRIT",
	FINAL: "FINAL",
	FUTURE: "FUT",
	LIVE: "LIVE",
	OFF: "OFF",
	PREGAME: "PRE",
};

export default APIGameStates;