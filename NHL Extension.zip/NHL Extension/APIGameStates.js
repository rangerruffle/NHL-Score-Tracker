const APIGameStates = {
	CRITICAL: "CRIT",
	FINAL: "FINAL",
	FUTURE: "FUT",
	LIVE: "LIVE",
	OFF: "OFF",
	POSTPONED: "PPD",
	PREGAME: "PRE",
	SHOOTOUT: "SO"
};

export default APIGameStates;